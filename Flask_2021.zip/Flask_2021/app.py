from flask import Flask,render_template,request,redirect,flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///MyToDos.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"]=False
db=SQLAlchemy(app)
app.secret_key = "super secret key"
class MyTodos(db.Model):
    sno=db.Column(db.Integer,primary_key=True)
    title=db.Column(db.String(200),nullable=False)
    desc=db.Column(db.String(500),nullable=False,unique=True)
    dates=db.Column(db.DateTime,default=datetime.utcnow)

    def __repr__(self)-> str:
        return f"{self.sno} - {self.title} - {self.desc}"

@app.route('/',methods=["GET","POST"])
def ToDo_page():
    if(request.method=="POST"):
        data= MyTodos.query.filter_by(desc=request.form["desc"]).first()
        print(data)
        if  data==None:

                todo=MyTodos(title=request.form["title"],desc=request.form["desc"])
            # request.cookies.clear()
                db.session.add(todo)
                db.session.commit()
       # print(dir(request))
        
        


    
    getTodos=MyTodos.query.all()
    #print(getTodos)

    return render_template("index.html",todos=getTodos)

@app.route('/delete/<int:sno>')
def delete(sno):
    todo=MyTodos.query.filter_by(sno=sno).first()
    db.session.delete(todo)
    db.session.commit()
    return redirect("/")

@app.route('/update/<int:sno>')
def update(sno):
    todo=MyTodos.query.filter_by(sno=sno).first()
    print(todo.title)
    #db.session.delete(todo)
   # db.session.commit()
    return render_template("update.html",todo=todo)

@app.route('/updated/<int:sno>',methods=["GET","POST"])
def updated(sno):
    if(request.method=="POST"):
       # todo=MyTodos(title=request.form["title"],desc=request.form["desc"])
        todo=MyTodos.query.filter_by(sno=sno).update(dict(title=request.form["title"],desc=request.form["desc"]))
        db.session.commit()
        flash("Todo is updated...")
        return redirect(request.url)
        
        
   # if(request.method=="POST"):
     #   todo=MyTodos(title=request.form["title"],desc=request.form["desc"])
     #   db.session.add(todo)
        
     #   print("req")
    return redirect("/")

if __name__=="__main__":
    app.run(debug=True)